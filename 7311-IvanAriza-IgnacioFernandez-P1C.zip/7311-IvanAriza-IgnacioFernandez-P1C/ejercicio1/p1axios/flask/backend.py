# app.py
from flask import Flask, jsonify, request
from flask_cors import CORS

# Crear la aplicación Flask
app = Flask(__name__)
CORS(app)  # Permitir peticiones desde Vue

# Datos de prueba
usuarios = [
    {"id": 1, "nombre": "Carlos"},
    {"id": 2, "nombre": "Lucía"}
]

# Ruta principal
@app.route("/")
def home():
    return "¡Servidor Flask funcionando correctamente!"

# Obtener usuarios (GET)
@app.route("/users", methods=["GET"])
def get_users():
    return jsonify(usuarios)

# Crear nuevo usuario (POST)
@app.route("/users", methods=["POST"])
def create_user():
    data = request.get_json()  # recibe JSON desde Vue
    nuevo = {
        "id": len(usuarios) + 1,
        "nombre": data["nombre"]
    }
    usuarios.append(nuevo)
    return jsonify(nuevo), 201  # status 201 = creado

# Ejecutar servidor
if __name__ == "__main__":
    app.run(debug=True)
