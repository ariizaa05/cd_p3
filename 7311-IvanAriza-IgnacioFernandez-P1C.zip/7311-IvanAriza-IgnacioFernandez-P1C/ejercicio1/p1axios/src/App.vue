<template>
  <main style="max-width:1000px;margin:0 auto;padding:16px">
    <nav style="display:flex;gap:12px">
      <RouterLink to="/">Inicio</RouterLink>
      <RouterLink to="/users">Usuarios</RouterLink>
    </nav>
    <RouterView />
  </main>
</template>

<script setup>
</script>
