<!-- src/views/HomeView.vue -->
<template>
  <h2>Home OK ✅</h2>
  <p>Ir a <router-link to="/users">Usuarios</router-link></p>
</template>
