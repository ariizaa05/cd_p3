<script setup>
import { ref } from 'vue'
import http from '../api/axios'

const emit = defineEmits(['created'])

const firstName = ref('')
const lastName  = ref('')
const email     = ref('')
const loading   = ref(false)
const error     = ref('')

async function submit() {
  loading.value = true
  error.value = ''
  try {
    const payload = { firstName: firstName.value, lastName: lastName.value, email: email.value }
    const { data } = await http.post('/users/add', payload)
    emit('created', data)
    firstName.value = lastName.value = email.value = ''
    alert(`Usuario creado (simulado): ${data.firstName} ${data.lastName} — id ${data.id}`)
  } catch (e) {
    error.value = e?.message || 'No se pudo crear el usuario'
  } finally {
    loading.value = false
  }
}
</script>



<template>
  <form @submit.prevent="submit" class="form">
    <input class="input" v-model="firstName" placeholder="Nombre" required />
    <input class="input" v-model="lastName"  placeholder="Apellido" required />
    <input class="input" v-model="email"     placeholder="Email" type="email" required />
    <button class="button" :disabled="loading">
      {{ loading ? 'Enviando...' : 'Crear usuario' }}
    </button>
  </form>
  <p v-if="error" style="color:#e66;margin-top:6px">{{ error }}</p>
</template>



<style scoped>
.form { display:flex; gap:8px; flex-wrap:wrap }
.input { padding:8px 10px; border:1px solid #ccc; border-radius:8px }
.button{ padding:8px 12px; border:0; border-radius:8px; background:#4f46e5; color:#fff; cursor:pointer }
</style>
