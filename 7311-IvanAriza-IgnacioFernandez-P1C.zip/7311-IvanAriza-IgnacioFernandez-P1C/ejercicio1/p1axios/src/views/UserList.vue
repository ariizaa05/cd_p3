

<script setup>
import { ref, onMounted } from 'vue'
import http from '../api/axios'
import UserForm from './UserForm.vue'

const users = ref([])
const loading = ref(false)
const error = ref('')

async function fetchUsers() {
  loading.value = true
  error.value = ''
  try {
    const { data } = await http.get('/users')
    users.value = data.users
  } catch (e) {
    error.value = e?.message || 'No se pudo cargar la lista'
  } finally {
    loading.value = false
  }
}

function handleCreated() {
  // La API no persiste, pero si quieres recargar:
  fetchUsers()
}

onMounted(fetchUsers) // carga al montar la vista
</script>


<template>
  <section style="max-width:900px;margin:16px auto;padding:12px">
    <h1>Usuarios — DummyJSON</h1>

    <UserForm @created="handleCreated" />

    <hr style="margin:16px 0" />

    <div v-if="loading">Cargando...</div>

    <ul v-else>
      <li v-for="u in users" :key="u.id">
        {{ u.firstName }} {{ u.lastName }} — {{ u.email }}
      </li>
    </ul>

    <p v-if="error" style="color:#e66">{{ error }}</p>
  </section>
</template>




