import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'   // usa rutas relativas
import UserList from '../views/UserList.vue'

const routes = [
  { path: '/', name: 'home', component: HomeView },
  { path: '/users', name: 'users', component: UserList },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

export default router


